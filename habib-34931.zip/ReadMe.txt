Introduction:
The lab was based on the development of surveys the main thing to implement was to make survey form and that will be only visible to authenticated user if its private. If its public than it will be visible to both type of users the authenticated and non authenticated users. The authenticated user will only be able to create survey either of public or private visibility.

Approach to Solve Problem:
Separate php pages and html pages were made and database was designed the email entered was taken from database and was compared with email entered at "sign in" page if both matched then the user was given access to create his public or private form.

How to Run Application?
The application must be unzipped under www folder and you must access it with it's path accordingly.

