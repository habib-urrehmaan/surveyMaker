<!--link github="https://github.com/habiburrehman012/surveyMaker"-->
<?php


if(isset($_POST["email"]) && isset($_POST["pass"])) //check if user has entered the username and password
{
	$servername = "localhost";
	$username = "root";
	$password = "root";
	$dbname = "survey";
	$con = mysqli_connect($servername,$username,$password,$dbname);

	
// Check connection
	if (mysqli_connect_errno())
  	{
  		echo "Failed to connect to MySQL: " . mysqli_connect_error();
  	}

  	else
  	{
  		//Apply query to get email and password that are stored in database
  		$sql = "SELECT email,password FROM authentication";
		$result = $con->query($sql);

		if ($result->num_rows > 0) 
		{
    	// output data of each row
    		while($row = $result->fetch_assoc()) 
    		{
    			//check whether email entered is valid or invalid
        		if($_POST["email"]==$row['email'] && $_POST['pass']==$row['password'])
        		{
					echo "<a href='form_generate.html'>MAKE SURVEY FORM</a>";
					exit();
				}
				else
					//display error in case of email and password is invalid
					echo "Error wrond email or password <a href='signIn.html'>Re Enter Credentials</a>";
    		}
    		/*while($row1=$formresult->fetch_assoc())
    		{
    			if($_POST[)	
    		}*/
		}	 
		else 
		{
    		echo "0 results";
		}
		//close the connection
		$con->close();	
  	}
}

else
echo "please enter your username<br/>";

?>