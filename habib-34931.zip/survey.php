<!--link github="https://github.com/habiburrehman012/surveyMaker"-->
<!doctype html>
<html>
<body>
<B>Page added Successfully</B>
</body>
</html>

<?php
$doc = new DomDocument;

// We need to validate our document before refering to the id
$doc->validateOnParse = true;
$doc->Load('book.form_generate.html');

//echo "The element whose id is 'php-basics' is: " . $doc->getElementById('radio1')->tagName . "\n";


?>